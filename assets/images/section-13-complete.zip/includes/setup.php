<?php

function up_setup_theme() {
  add_image_size('teamMember', 56, 56, true);
}